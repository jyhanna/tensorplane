from setuptools import setup, find_packages

setup(
	name='tensorplane',
	version='0.0.1',
	author='Jonathan Hanna',
	author_email='jonathanyussefhanna@gmail.com',
	packages=find_packages(),
	license='LICENSE.txt',
	url='https://github.com/JonathanHanna/tensorplane',
	description='A modular and expressive interface for managing data in Python',
	long_description=open('README.md').read(),
	long_description_content_type='text/markdown',
	install_requires=[
        "numpy >= 1.15.0",
	],
	classifiers=[
		'Development Status :: 2 - Pre-Alpha',
		'Intended Audience :: Developers',
		'Topic :: Scientific/Engineering :: Artificial Intelligence',
		'License :: OSI Approved :: BSD License',
		'Programming Language :: Python :: 3'
	]
)
